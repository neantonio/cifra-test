alter table CIFRA_DOCUMENT drop column DOC_TYPE__U73459 cascade ;
