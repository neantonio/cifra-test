alter table CIFRA_CHECK_LIST_ITEMS drop column CHECK_LIST_ID__U75477 cascade ;
