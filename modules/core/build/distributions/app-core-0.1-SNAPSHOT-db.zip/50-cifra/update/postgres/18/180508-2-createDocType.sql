create unique index IDX_CIFRA_DOC_TYPE_UK_NAME on CIFRA_DOC_TYPE (NAME) where DELETE_TS is null ;
