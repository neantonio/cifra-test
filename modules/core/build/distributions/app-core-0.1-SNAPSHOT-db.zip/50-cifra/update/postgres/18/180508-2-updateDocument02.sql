alter table CIFRA_DOCUMENT alter column DATE_LOAD drop not null ;
