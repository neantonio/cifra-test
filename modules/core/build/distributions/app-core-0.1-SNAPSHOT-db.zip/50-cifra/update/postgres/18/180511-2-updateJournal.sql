alter table CIFRA_JOURNAL add column WAREHOUSE_ID uuid ;
