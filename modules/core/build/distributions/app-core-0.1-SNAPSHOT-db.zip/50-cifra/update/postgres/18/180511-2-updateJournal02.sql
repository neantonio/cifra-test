alter table CIFRA_JOURNAL rename column address to address__u00838 ;
alter table CIFRA_JOURNAL add column CELL varchar(255) ;
