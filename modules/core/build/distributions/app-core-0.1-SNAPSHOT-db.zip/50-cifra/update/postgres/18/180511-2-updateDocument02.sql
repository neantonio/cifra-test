alter table CIFRA_DOCUMENT rename column address to address__u65025 ;
alter table CIFRA_DOCUMENT add column CELL varchar(50) ;
