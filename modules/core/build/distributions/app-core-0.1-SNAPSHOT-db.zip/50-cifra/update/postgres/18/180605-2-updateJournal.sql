alter table CIFRA_JOURNAL add column PREVIOUS_STATUS integer ;
