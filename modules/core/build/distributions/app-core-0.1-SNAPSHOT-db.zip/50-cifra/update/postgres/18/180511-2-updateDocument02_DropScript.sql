alter table CIFRA_DOCUMENT drop column ADDRESS__U65025 cascade ;
