create unique index IDX_CIFRA_COMPANY_UK_NAME on CIFRA_COMPANY (NAME) where DELETE_TS is null ;
