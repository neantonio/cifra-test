alter table CIFRA_DOCUMENT add column CONTRAGENT_ID uuid ;
alter table CIFRA_DOCUMENT add column COMPANY_ID uuid ;
alter table CIFRA_DOCUMENT add column DIVISION_ID uuid ;
