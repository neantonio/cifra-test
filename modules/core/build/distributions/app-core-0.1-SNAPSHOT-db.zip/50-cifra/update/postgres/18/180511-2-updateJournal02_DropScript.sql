alter table CIFRA_JOURNAL drop column ADDRESS__U00838 cascade ;
