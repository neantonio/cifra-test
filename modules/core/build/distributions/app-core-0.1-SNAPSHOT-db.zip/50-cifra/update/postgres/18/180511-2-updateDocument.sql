alter table CIFRA_DOCUMENT add column WAREHOUSE_ID uuid ;
alter table CIFRA_DOCUMENT add column ADDRESS varchar(50) ;
